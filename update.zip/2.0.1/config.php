<?php

$pdo = new PDO('mysql:host=localhost;dbname=fP', 'fP', 'y1VhCIgsU4jw3G3ivaE5');

$ext_version_loc = "https://pastebin.com/raw/YBGEBviB";